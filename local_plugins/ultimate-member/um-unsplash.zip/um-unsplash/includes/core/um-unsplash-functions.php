<?php if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! class_exists( 'UM_Unsplash_Functions' ) ) {


	/**
	 * Class UM_Unsplash_Functions
	 */
	class UM_Unsplash_Functions {


		/**
		 * UM_Unsplash_Functions constructor.
		 */
		function __construct() {
			add_action( 'um_cover_area_content', array( $this, 'show_photo_attribution' ), 10, 1 );
		}


		/**
		 *
		 */
		function show_photo_attribution() {
			$cover_pic = get_user_meta( um_profile_id(), '_um_unsplash_cover', true );
			$pic_author = get_user_meta( um_profile_id(), '_um_unsplash_photo_author', true );
			$author_url = get_user_meta( um_profile_id() , '_um_unsplash_photo_author_url', true );
			$download_url = get_user_meta( um_profile_id() , '_um_unsplash_photo_download_url', true );
			$download_url .= '?force=true';

			if ( $cover_pic && $pic_author ) { ?>

				<span class="um-unsplash-attribution">
					<?php printf( __( 'Photo by <a target="_blank" class="author-url" href="%s">%s</a> on Unsplash <a class="download-url" target="_blank" href="%s"><i class="um-faicon-download"></i></a>', 'um-unsplash' ), $author_url, ucfirst( esc_html( $pic_author ) ), $download_url ); ?>
				</span>

			<?php }
		}
	}
}
