<?php

require_once( dirname( __FILE__ ) . '/class-itsec-two-factor.php' );
ITSEC_Two_Factor::get_instance();
